import serial
import time
import numpy as np
import matplotlib.pyplot as plt
import os
from scipy.io import savemat

# Obtener la ruta al directorio actual donde se encuentra el código para guardar después en esta misma ruta la imagen y el txt
current_directory = os.path.dirname(os.path.abspath(__file__))

arduino = serial.Serial('COM9', 9600, timeout=0.01)  # Especifica el puerto serial y la velocidad de transmisión 
time.sleep(2)

numero_datos = 1000  # Número de datos a adquirir

EMG = np.ndarray((0), dtype=int)  
# Contador para distinguir entre archivos y que no se sobreescriban ( le aumentabamos 1 manualmente con cada paciente ) 
contador = 7

# Mientras el arreglo no tenga los datos que requiero, los solicito
while EMG.shape[0] < numero_datos: 
    datos = arduino.readlines(arduino.inWaiting())
    datos_por_leer = len(datos)
  
    if len(datos) > numero_datos:
        datos = datos[0:numero_datos]
        valores_leidos = np.zeros(numero_datos, dtype=int)
    else:
        valores_leidos = np.zeros(datos_por_leer, dtype=int)
    
    posicion = 0
    # Se convierten los datos a valores numéricos de voltaje
    for dato in datos:
        try:
            valores_leidos[posicion] = int(dato.decode().strip())
        except:
            # Si no puedo convertir, completo la muestra con el anterior
            valores_leidos[posicion] = valores_leidos[posicion-1]
        posicion += 1
    # Agrego los datos leídos al arreglo
    EMG = np.append(EMG, valores_leidos)
    # Introduzco un delay para que se llene de nuevo el buffer
    time.sleep(2)

# Como la última lectura puede tener más datos de los que necesito, descarto las muestras restantes
EMG = EMG[:numero_datos]

# Graficar la señal con la cantidad de datos tomados en el eje x
plt.plot(range(numero_datos), EMG)

# Configurar etiquetas de los ejes
plt.xlabel('Cantidad de datos tomados')
plt.ylabel('EMG')

# Guardar la señal como un archivo .mat
file_path_mat = os.path.join(current_directory, f'señal_captada_{contador}.mat')
savemat(file_path_mat, {'EMG': EMG})

# Guardar la señal como un archivo de imagen JPG
file_path_jpg = os.path.join(current_directory, f'señal_captada_{contador}.jpg')
plt.savefig(file_path_jpg)

# Mostrar la gráfica
plt.show()

# Cerrar puerto serial, siempre debe cerrarse
arduino.close()
